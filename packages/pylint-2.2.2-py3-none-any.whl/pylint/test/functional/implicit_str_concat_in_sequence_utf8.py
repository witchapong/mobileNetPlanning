#pylint: disable=bad-continuation,invalid-name,missing-docstring

TOTO = ('Café', 'Café', 'Café')
